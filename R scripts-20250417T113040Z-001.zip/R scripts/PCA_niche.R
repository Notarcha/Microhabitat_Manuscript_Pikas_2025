library("FactoMineR")
library("factoextra")
library("rgl")
library("pca3d")
library("sos")

x <-PCA(PCA_2[,2:12], scale.unit = TRUE, ncp = 5, graph = TRUE)

fviz_pca_ind(x,
             geom.ind = "point", # show points only (nbut not "text")
             col.ind = PCA_2$Group, # color by groups
             palette = c("#00AFBB", "#E7B800", "#FC4E07"),label = "var",
             col.var = "black",
             addEllipses = FALSE, # Concentration ellipses
             legend.title = "Groups"
)

fviz_pca_biplot(x, 
                col.ind = PCA_2$Group, palette = "jco", 
                addEllipses = TRUE, label = "var",
                col.var = "black", repel = TRUE,
                legend.title = "Species") 

library(siar)
y <- prcomp(PCA_2[,2:12], center = TRUE, scale. = TRUE)
species <- PCA_2[, 13]
g <- ggbiplot(y, obs.scale = 1, var.scale = 1, 
              groups = species, ellipse = TRUE,
              circle = TRUE)
g <- g + scale_color_discrete(name = '')
g <- g + theme(legend.direction = 'horizontal', 
               legend.position = 'top')
print(g)
macrotis <- y$x[species=="macrotis",]
nubrica <- y$x[species=="nubrica",]
ladacensis <-y$x[species=="ladacensis"]
overlap(versicolor[,1], versicolor[,2], nubrica[,1], nubrica[,2], ladacensis[,1], ladacensis[,2], steps = 5)
