#preliminary analysis

library(tidyverse)
library(lme4)
library(sjPlot)
library(corrplot)
library(factoextra)
library(MASS)
library(lmtest)
library(ResourceSelection)
library(arm)
library(ggplot2)
library(cowplot)
library(ggbeeswarm)

#Figure 2
a<-ggplot(X, aes(x=Group, y=DEM, colour=Group)) + geom_boxplot(width = 0.75, size = 0.75, position = position_dodge(0.8)) + geom_dotplot(aes(fill = Group, colour=Group), binaxis='y', stackdir='center', binwidth= 1 ,dotsize = 15,position = position_dodge(0.8)) + labs(title="", x ="Plots", y = "Elevation") + theme_cowplot(12)
a+scale_fill_manual(values=c("#8c510a","#d8b365","#5ab4ac","#01665e","#762a83","#af8dc3"), guide = guide_legend(reverse = TRUE)) + theme(axis.text=element_text(size=20),
                                                                                                 axis.title=element_text(size=20))+ theme(legend.key.size = unit(1, 'cm'), legend.text = element_text(size=10)) + scale_color_manual(values=c("#8c510a","#d8b365","#5ab4ac","#01665e","#762a83","#af8dc3"), guide = guide_legend(reverse = TRUE))

#Can PC transformed variables be used for regressions? 
#rawdata
d <- All_data
head(d)
d<-na.omit(d)
matrix = cor(d[,5:38])
corrplot(matrix,method = 'number', type = 'upper')

#uncorrelated variables that are likely to be of importance
d <- Uncorrelated_plotdata_OM_ON_OL
head(d)
d<-na.omit(d)
matrix = cor(d[,5:38])
corrplot(matrix,method = 'number', type = 'upper')

#PCA 
uncorrelated_var.pca <- prcomp(d[,4:17], center = TRUE,scale. = TRUE)
summary(uncorrelated_var.pca)
library(devtools)
library(ggbiplot)
ggbiplot(uncorrelated_var.pca)
fviz_screeplot(uncorrelated_var.pca)

#Only 40% variation explained by first 2 PC axes. So, dimensionality reduction doesn't seem like the best idea. 


#univariate_models_ladacensis_allplots
lapply(c("Percentage_vegetation","Percentage_rocks","Percentage2_rocks","Percentage3_rocks","Percentage4_or_larger_rocks","number_short_grass._sedge","number_tall_Grass._reeds","number_Herb._Forb_","number_Shrub","Percentage_Shrub", "Height_short_grass._sedge_", "Height_tall_Grass._reeds", "Height_Herb._Forb_", "Height_Shrub"),
       
       function(var) {
         
         
         formula    <- as.formula(paste("ladacensis ~", var))
         boxplotformula <- as.formula(paste(var,"~ ladacensis"))
         res.logist <- glm(formula, data = d, family = binomial)
         boxplot(boxplotformula, data = d)
         
         summary(res.logist)
         plot_model(res.logist, type='pred', terms = var)
       })

Comments: #Percentage vegetation, height of grass, height of forbs as important predictors of ladacensis.


##fixing landscape level differences in vegetation structure and composition across Wari La and Tsokar. For analysis of drivers of distribution of OL and ON, we subset and use only data from Tsokar


  
  
  

  
  
  
  
  

##ON data
d <- all plot data
head(d)
m<-na.omit(d)

#univariate_models_nubrica_allplots
lapply(c("Percentage_vegetation","Percentage_rocks","Percentage_bare_ground","Percentage1_rocks" ,"Percentage2_rocks","Percentage3_rocks","Percentage4_or_larger_rocks","number_short_grass._sedge","number_tall_Grass._reeds","number_Herb._Forb_","number_Shrub","Percentage_short_grass._sedge", "Percentage_tall_Grass._reeds", "Percentage_Herb._Forb_","Percentage_Shrub", "Height_short_grass._sedge_", "Height_tall_Grass._reeds", "Height_Herb._Forb_", "Height_Shrub"),
       
       function(var) {
         
         formula    <- as.formula(paste("nubrica ~", var))
         boxplotformula <- as.formula(paste(var,"~ nubrica"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary.glm(res.logist)
       })

#comments - Percentage vegetation, number of shrubs, Height of shrubs, Percentage shrubs seems to be important. But there are outliers that obscure the relationship. 
# These are probably a result of pooling Wari La and Tsokar plots with different vegetation characteristics. But the dataset shows us something that the Tsokar dataset doesn't. 

#stepwise selection

#a) Biologically relevant model

full.model <- bayesglm(nubrica ~ Percentage_vegetation + number_Shrub + Height_Shrub + Percentage_Shrub , family = binomial, data = d, maxit=1000)
# Stepwise regression model
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)

#b) Statistically relevant model
full.model <- bayesglm(nubrica ~ Percentage_vegetation + Percentage_bare_ground+ Percentage1_rocks+ Percentage3_rocks+ Percentage4_or_larger_rocks+ number_short_grass._sedge+ number_Herb._Forb_+ Percentage_short_grass._sedge+ Percentage_Herb._Forb_+ Percentage_Shrub+ Height_short_grass._sedge_ + Height_tall_Grass._reeds + Height_Herb._Forb_+Height_Shrub, family = binomial, data = d, maxit=1000)
# Stepwise regression model
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE, maxit=1000)
summary(step.model)

#univariate_models_nubrica_Tsokarplots
m <- Master_datasheet_OL_ON_Tsokar
head(m)
m<-na.omit(m)

lapply(c("Percentage_vegetation","Percentage_rocks","Percentage_bare_ground","Percentage1_rocks" ,"Percentage2_rocks","Percentage3_rocks","Percentage4_or_larger_rocks","number_short_grass._sedge","number_tall_Grass._reeds","number_Herb._Forb","number_Shrub","Percentage_short_grass._sedge", "Percentage_tall_Grass._reeds", "Percentage_Herb._Forb","Percentage_Shrub", "Height_short_grass._sedge", "Height_tall_Grass._reeds", "Height_Herb._Forb", "Height_Shrub"),
       
       function(var) {
         
         
         formula    <- as.formula(paste("nubrica ~", var))
         boxplotformula <- as.formula(paste(var,"~ nubrica"))
         res.logist <- glm(formula, data = m, family = binomial)
         summary.glm(res.logist)
         plot_model(res.logist, type='pred', terms = var)
         boxplot(boxplotformula, data = m)
       })

#stepwise selection

#a) Biologically relevant model
full.model <- bayesglm(nubrica ~ Percentage_vegetation + number_Shrub + Height_Shrub + Percentage_Shrub , family = binomial, data = m, maxit=1000)
# Stepwise regression model
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)

#height of shrub also matters. But due to low sample size and complete absence of bushes in many plots at Tsokar, this leads to fitted probabilities numerically 0 or 1. 
model <- glm(nubrica ~ Percentage_vegetation + number_Shrub + Height_Shrub, data=m, family=binomial, maxit=1000)
summary(model)
m$predicted <- predict (nubrica ~ Percentage_vegetation + number_Shrub + Height_Shrub, m, type="response") #examine dataframe m. See possible reasons why this could be happeing.
#could either be small sample size or that predicted probabilities are indistinguishable from 0 and 1.

#b) Statistically relevant model
#Toskar plots only
full.model <- bayesglm(nubrica ~ Percentage_vegetation + Percentage_bare_ground+ Percentage1_rocks+ Percentage2_rocks+ Percentage3_rocks + Percentage4_or_larger_rocks+ number_short_grass._sedge + number_Herb._Forb + number_Shrub + Percentage_short_grass._sedge + Percentage_Herb._Forb + Percentage_Shrub + Height_tall_Grass._reeds + Height_Herb._Forb + Height_Shrub , family = binomial, data = m, maxit=1000)
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)

#all plots 
full.model <- bayesglm(nubrica ~ Percentage_vegetation + Percentage_bare_ground+ Percentage1_rocks+ Percentage3_rocks + Percentage4_or_larger_rocks + number_short_grass._sedge + number_Herb._Forb_+ Percentage_short_grass._sedge+ Percentage_Herb._Forb_ + Percentage_Shrub + Height_short_grass._sedge_ + Height_tall_Grass._reeds + Height_Herb._Forb_ + Height_Shrub, family = binomial, data = d, maxit=1000)
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)

#Comments: Height of shrubs, number of shrubs and percentage vegetation associated with nubra pika presence

#OL data

lapply(c("Percentage_vegetation","Percentage_rocks","Percentage2_rocks","Percentage3_rocks","Percentage4_or_larger_rocks","number_short_grass._sedge","number_tall_Grass._reeds","number_Herb._Forb_","number_Shrub","Percentage_Shrub", "Height_short_grass._sedge_", "Height_tall_Grass._reeds", "Height_Herb._Forb_", "Height_Shrub"),
       
       function(var) {
         
         
         formula    <- as.formula(paste("ladacensis ~", var))
         boxplotformula <- as.formula(paste(var,"~ ladacensis"))
         res.logist <- glm(formula, data = m, family = binomial)
         boxplot(boxplotformula, data = m)
         
         summary(res.logist)
         plot_model(res.logist, type='pred', terms = var)
       })

#Comments: Only height of herbs/forbs as predictor for Ladakh pika presence. It would be interesting to know if it is associated with large grazing pressure. 

#univariate_models_macrotis_allplots
d <- Plot_data_OM_ON_OL
head(d)
d<-na.omit(d)
lapply(c("Percentage_vegetation","Percentage_rocks","Percentage2_rocks","Percentage3_rocks","Percentage4_or_larger_rocks","number_short_grass._sedge","number_tall_Grass._reeds","number_Herb._Forb_","number_Shrub","Percentage_Shrub", "Height_short_grass._sedge_", "Height_tall_Grass._reeds", "Height_Herb._Forb_", "Height_Shrub"),
       
       function(var) {
         
         
         formula    <- as.formula(paste("macrotis ~", var))
         boxplotformula <- as.formula(paste(var,"~ macrotis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         boxplot(boxplotformula, data = d)
         plot_model(res.logist, type='pred', terms = var)
       })

#comments - Percentage vegetation (less vegetation more pika), Percentage rocks, Percentage 3 rocks, Percentage 4 and 4+ rocks, number of herbs and forbs seem to be important. 

#stepwise selection_selectedvariables
full.model <- glm(macrotis ~Percentage_rocks + Percentage2_rocks + Percentage3_rocks + Percentage4_or_larger_rocks + number_Herb._Forb_ + Percentage_Herb._Forb_ + Percentage_Shrub, family = binomial, data = d)
# Stepwise regression model
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)

#checking for interactions
m001<- glm(macrotis ~Percentage_rocks * number_Herb._Forb_ * Percentage_Shrub, family = binomial, data = d)
summary(m001)
m002 <-glm(macrotis ~Percentage_rocks + number_Herb._Forb_ + Percentage_Shrub , family = binomial, data = d)
summary(m002)
lrtest(m002,m001)

#appears that interactions are not important. 

Predprob<-predict(m002,type="response")
plot(Predprob,jitter(as.numeric(m002$data$macrotis),0.5),cex=0.5,ylab="Jittered mortality outcome")

#doesn't exactly look like the best scenario out there. But will do for now I suppose.
