library(tidyverse)
library(lme4)
library(sjPlot)
library(corrplot)
library(factoextra)
library(MASS)
library(lmtest)
library(ResourceSelection)
library(arm)

#univariate_models_nubrica_allplots

lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("nubrica ~", var))
         boxplotformula <- as.formula(paste(var,"~ nubrica"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         plot_model(res.logist, type='pred', terms = var)
       })

#a)statistically relevant model
full.model <- glm(nubrica~ perc_vegetation + perc_rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks+num_shortgrass_sedge+perc_herb_forb+perc_shrub+ height_tallgrass_reeds + height_herb_forb + height_shrub+height_trees+Slope+ NDVI_august+NDVI_december,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#b)Purposeful selection model
full.model <- glm(nubrica~ perc_vegetation + perc_rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks+num_shortgrass_sedge+perc_herb_forb+perc_shrub+ height_tallgrass_reeds + height_herb_forb + height_shrub+height_trees+Slope+ NDVI_august+NDVI_december+perc_2rocks+num_tallgrass_reeds+Aspect,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#c)Sub-modelling approach
#rocks
full.model <- glm(nubrica~perc_rocks+perc_2rocks+perc_3rocks+perc_4rocks+num_3rocks+num_4rocks,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(nubrica~perc_vegetation+perc_bareground+perc_shortgrass_sedge+perc_tallgrass_reeds+perc_herb_forb+perc_shrub,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(nubrica ~ num_shortgrass_sedge+ num_tallgrass_reeds + num_shrub,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(nubrica ~ height_shortgrass_sedge + height_tallgrass_reeds + height_herb_forb+ height_shrub + height_trees, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(nubrica ~ Slope + NDVI_august + NDVI_december, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm(nubrica ~ perc_3rocks + perc_4rocks + num_shrub+ perc_vegetation + perc_bareground + perc_herb_forb + perc_shrub+  height_shortgrass_sedge + height_tallgrass_reeds + height_shrub + height_trees + Slope,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#spatial level : Changthang
#univariate_models_nubrica_Changthang

lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("nubrica ~", var))
         boxplotformula <- as.formula(paste(var,"~ nubrica"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

#a)statistically relevant model
full.model <- glm(nubrica ~num_shrub + perc_shortgrass_sedge + perc_herb_forb + perc_shrub + height_tallgrass_reeds + height_shrub,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#b)Purposeful selection model
full.model <- glm(nubrica ~ perc_vegetation+ num_shrub + perc_shortgrass_sedge + perc_herb_forb + perc_shrub + height_tallgrass_reeds + height_shrub+perc_1rocks+perc_3rocks +height_shortgrass_sedge+ DEM.elevation+Slope+Aspect,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#c)Sub-modelling approach
#rocks
full.model <- glm(nubrica ~ perc_1rocks+perc_3rocks,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(nubrica ~ perc_vegetation+perc_bareground+perc_shrub+perc_shortgrass_sedge+perc_herb_forb,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(nubrica ~ num_shortgrass_sedge+ num_tallgrass_reeds + num_shrub,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(nubrica ~ height_shortgrass_sedge + height_tallgrass_reeds + height_herb_forb+ height_shrub + height_trees, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(nubrica ~ DEM.elevation+Slope+Aspect, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm(nubrica ~ Slope + num_shrub + perc_bareground + perc_shrub + num_shrub + perc_1rocks + perc_3rocks,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#### West Ladakh only 
lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("nubrica ~", var))
         boxplotformula <- as.formula(paste(var,"~ nubrica"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

#a)statistically relevant model
full.model <- glm(nubrica ~ perc_vegetation + num_shrub + perc_shrub + height_tallgrass_reeds + height_herb_forb + height_shrub + height_trees + NDVI_august + NDVI_december,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#b)Purposeful selection model
full.model <- glm(nubrica ~ perc_vegetation + num_shrub + perc_shrub + height_tallgrass_reeds + height_herb_forb + height_shrub + height_trees + NDVI_august + NDVI_december+ perc_1rocks + perc_tallgrass_reeds + perc_herb_forb + height_shortgrass_sedge + DEM.elevation +Slope + Aspect,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#c)Sub-modelling approach
#rocks
full.model <- glm(nubrica ~ perc_1rocks+perc_3rocks,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(nubrica ~ perc_vegetation + perc_shrub + perc_tallgrass_reeds + perc_herb_forb ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(nubrica ~ num_shrub + num_tallgrass_reeds + num_shortgrass_sedge,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(nubrica ~ height_tallgrass_reeds + height_herb_forb + height_shrub + height_trees + height_shortgrass_sedge, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(nubrica ~ NDVI_august + NDVI_december+ DEM.elevation +Slope + Aspect, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm(nubrica ~ DEM.elevation + Slope +  height_tallgrass_reeds + height_trees + perc_vegetation + perc_shrub + perc_herb_forb + num_shrub + num_tallgrass_reeds + perc_1rocks ,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
