library(tidyverse)
library(lme4)
library(sjPlot)
library(corrplot)
library(factoextra)
library(MASS)
library(lmtest)
library(ResourceSelection)
library(arm)

#univariate_models_nubrica_allplots

lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("ladacensis ~", var))
         boxplotformula <- as.formula(paste(var,"~ ladacensis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         plot_model(res.logist, type='pred', terms = var)
       })

#a)statistically relevant model
full.model <- glm(ladacensis ~ perc_rocks + perc_4rocks + num_4rocks + height_herb_forb + height_cushionplant + DEM.elevation + NDVI_december,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
summary(step.model)

#b)Purposeful selection model
full.model <- glm(ladacensis ~ perc_rocks + perc_4rocks + num_4rocks + height_herb_forb + height_cushionplant + DEM.elevation + NDVI_december +perc_1rocks + num_3rocks+ perc_cushionplant + perc_trees + height_shortgrass_sedge + height_shrub + Slope + Aspect,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#c)Sub-modelling approach
#rocks
full.model <- glm(ladacensis ~ perc_rocks + perc_4rocks + num_4rocks + perc_1rocks + num_3rocks,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(ladacensis ~ perc_cushionplant + perc_trees ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(nubrica ~ num_shortgrass_sedge+ num_tallgrass_reeds + num_shrub,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(ladacensis ~ height_herb_forb + height_cushionplant + height_shortgrass_sedge + height_shrub , family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(ladacensis ~DEM.elevation + NDVI_december + Slope + Aspect, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm(ladacensis ~  perc_rocks + perc_4rocks + num_4rocks + perc_1rocks +  perc_cushionplant + perc_trees + height_herb_forb + height_cushionplant + height_shrub + DEM.elevation + NDVI_december + Aspect,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#completely biological model
full.model <- glm(ladacensis ~ perc_vegetation + height_shortgrass_sedge + height_herb_forb + DEM.elevation+Slope+Aspect +NDVI_august+NDVI_december,family=binomial, data=d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#### changthang only

lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("ladacensis ~", var))
         boxplotformula <- as.formula(paste(var,"~ ladacensis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

###a)statistically relevant model
full.model <- glm(ladacensis ~ DEM.elevation + Slope + NDVI_december ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
summary(step.model)

#b)Purposeful selection model
full.model <- glm(ladacensis ~ DEM.elevation + Slope + NDVI_december+NDVI_august+Aspect+height_cushionplant+height_shrub+height_herb_forb + height_shortgrass_sedge + perc_cushionplant + perc_shrub + num_shrub + num_4rocks + perc_4rocks + perc_1rocks + perc_rocks+perc_vegetation,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#c)Sub-modelling approach
#rocks
full.model <- glm(ladacensis ~ num_4rocks + perc_4rocks + perc_1rocks,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(ladacensis ~ perc_vegetation +perc_shrub +perc_cushionplant,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(ladacensis ~ num_shrub ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(ladacensis ~ height_cushionplant+ height_shrub+height_herb_forb + height_shortgrass_sedge, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(ladacensis ~ DEM.elevation + Slope + NDVI_december + NDVI_august + Aspect,  family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm(ladacensis ~ DEM.elevation + NDVI_december + NDVI_august + Aspect + height_cushionplant + height_shrub + height_herb_forb + perc_vegetation +perc_shrub +perc_cushionplant +  num_shrub +  DEM.elevation + NDVI_december,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#### West Ladakh only 
lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","NDVI_august","NDVI_december"),
       function(var) {
         
         
         formula    <- as.formula(paste("ladacensis ~", var))
         boxplotformula <- as.formula(paste(var,"~ ladacensis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

