library(tidyverse)
library(lme4)
library(sjPlot)
library(corrplot)
library(factoextra)
library(MASS)
library(lmtest)
library(ResourceSelection)
library(arm)
library(caret)

#univariate_models_macrotis_allplots
d <- Master_datasheet_OM_ON_OL_Wari.La.and.Tsokar
head(d)
d<-na.omit(d)
lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","Average.Delta.NDVI",  "STD.NDVI","Average.NDVI_Nov_Dec", "STDEV.NDVI_November_December", "Average.NDVI_July_August", "STDEV.NDVI_July_August"),
       function(var) {
         
         
         formula    <- as.formula(paste("macrotis ~", var))
         boxplotformula <- as.formula(paste(var,"~ macrotis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

plot_model(res.logist, type='pred', terms = var)
#comments - Percentage vegetation (less vegetation more pika), Percentage rocks, Percentage 3 rocks, Percentage 4 and 4+ rocks, number of herbs and forbs seem to be important. 

#stepwise selection_selectedvariables

#a)statistically relevant model
full.model <- glm(macrotis ~ perc_bareground + perc_vegetation+ perc_rocks+ perc_3rocks + perc_4rocks + num_3rocks+ num_4rocks + perc_herb_forb + perc_shrub + DEM.elevation + Slope + Average.NDVI_Nov_Dec , family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
variable_importance<-varImp(step.model, scale = FALSE)


#b)Purposeful selection
full.model <- glm(macrotis ~ perc_bareground + perc_vegetation+ perc_rocks+ perc_3rocks + perc_4rocks + num_3rocks+ num_4rocks + perc_herb_forb + perc_shrub + DEM.elevation + Slope + Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August + height_tallgrass_reeds+ num_tallgrass_reeds+ num_shortgrass_sedge + perc_2rocks , family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
variable_importance<-varImp(step.model, scale = FALSE)
write.csv(variable_importance,"OM_Ladakh_purposefulmodel.csv")


#c)Sub-modelling approach
#rocks
full.model <- glm(macrotis ~ perc_rocks + perc_2rocks + perc_3rocks + perc_4rocks+ num_3rocks+ num_4rocks, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#fix this
one <- bayesglm(macrotis ~ perc_vegetation + perc_herb_forb + perc_shrub + perc_tallgrass_reeds+ perc_bareground, family = binomial, data = d)
two <- bayesglm(macrotis ~ Percentage3_rocks + Percentage4_or_larger_rocks , family = binomial, data = d)
three <- bayesglm(macrotis ~Percentage2_rocks + Percentage4_or_larger_rocks , family = binomial, data = d)
four <- bayesglm(macrotis ~ Percentage3_rocks  , family = binomial, data = d)
delta.coef<-abs((coef(three)-coef(one)[-4])/coef(one)[-4])
delta.coef
lrtest(one,three)

hoslem.test(one$data$macrotis, one$fitted)
hoslem.test(two$data$macrotis, two$fitted)
hoslem.test(three$data$macrotis, three$fitted)
hoslem.test(full.model$data$macrotis, full.model$fitted)

#vegetation_1
full.model <- glm(macrotis ~ perc_vegetation + perc_herb_forb + perc_shrub + perc_tallgrass_reeds+ perc_bareground +Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
one<- bayesglm(macrotis ~ number_Herb._Forb_, family = binomial, data = d)
two<- bayesglm(macrotis ~ number_tall_Grass._reeds, family = binomial, data = d)
summary(one)
summary(two)
lrtest(full.model,one)
#vegetation_2
full.model <- bayesglm(macrotis ~ num_shortgrass_sedge + num_tallgrass_reeds, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
one <- bayesglm(macrotis ~ Percentage_vegetation+ Percentage_bare_ground+ Percentage_Herb._Forb_, family = binomial, data = d)
two <- bayesglm(macrotis ~ Percentage_vegetation+ Percentage_bare_ground, family = binomial, data = d)
three <- bayesglm(macrotis ~ Percentage_vegetation, family = binomial, data = d)

delta.coef<-abs((coef(one)-coef(full.model)[-4])/coef(full.model)[-4])
delta.coef
lrtest(full.model,one)
 
delta.coef<-abs((coef(two)-coef(one)[-4])/coef(one)[-4])
delta.coef
lrtest(one,two)
lrtest(two,alternative)

#vegetation_3
full.model <- glm(macrotis ~ height_tallgrass_reeds, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
one <- bayesglm(macrotis ~ Height_tall_Grass._reeds + Height_Herb._Forb_ + Height_Shrub, family = binomial, data = d)
two <- bayesglm(macrotis ~ Height_tall_Grass._reeds + Height_Herb._Forb_, family = binomial, data = d)
three <- bayesglm(macrotis ~ Height_tall_Grass._reeds, family = binomial, data = d)

#geographic features
full.model <- glm(macrotis ~ DEM.elevation + Slope, data = d, family = binomial)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
one <- bayesglm(macrotis ~ DEM.elevation + Slope, data = d, family = binomial) 
two <- bayesglm(macrotis ~ DEM.elevation , data = d, family = binomial) 

hoslem.test(one$data$macrotis, one$fitted)
hoslem.test(two$data$macrotis, two$fitted)
hoslem.test(three$data$macrotis, three$fitted)
hoslem.test(full.model$data$macrotis, full.model$fitted)
hoslem.test(alternative$data$macrotis, alternative$fitted)


#mixed model
full.model<- glm(macrotis ~ perc_rocks + perc_2rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks + perc_vegetation + perc_herb_forb + perc_shrub + perc_tallgrass_reeds + perc_bareground + Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August + num_shortgrass_sedge + num_tallgrass_reeds + height_tallgrass_reeds + DEM.elevation + Slope, data = d, family = binomial)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
one<-bayesglm(macrotis ~ GPS.elevation + Slope + Percentage_vegetation + Percentage4_or_larger_rocks + number_Herb._Forb_ + number_tall_Grass._reeds, data = d, family = binomial)
two<-bayesglm(macrotis ~ GPS.elevation + Slope + Percentage_vegetation + Percentage4_or_larger_rocks + number_Herb._Forb_, data = d, family = binomial)
three<-bayesglm(macrotis ~ GPS.elevation + Slope + Percentage_vegetation + Percentage4_or_larger_rocks, data = d, family = binomial)
alternative<-glm(macrotis ~ perc_3rocks + perc_4rocks + num_4rocks + perc_herb_forb + Slope, data=d, family = binomial)

variable_importance<-varImp(step.model, scale = FALSE)
write.csv(variable_importance,"OM_Ladakh_submodel.csv")


## Changthang only spatial model

lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect","Average.Delta.NDVI",  "STD.NDVI","Average.NDVI_Nov_Dec", "STDEV.NDVI_November_December", "Average.NDVI_July_August", "STDEV.NDVI_July_August"),
       function(var) {
         
         
         formula    <- as.formula(paste("macrotis ~", var))
         boxplotformula <- as.formula(paste(var,"~ macrotis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })


#a)statistically relevant model
full.model <- glm(macrotis ~perc_bareground + perc_vegetation + perc_rocks + perc_2rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks+ perc_herb_forb + DEM.elevation,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#b)Purposeful selection model
full.model <- glm(macrotis ~perc_bareground + perc_vegetation + perc_rocks + perc_2rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks+ perc_herb_forb + DEM.elevation + perc_shrub + Slope + STDEV.NDVI_November_December,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
variable_importance<-varImp(step.model, scale = FALSE)
write.csv(variable_importance,"OM_Changthang_purposefulmodel.csv")

#c)Sub-modelling approach
#rocks
full.model <- glm(macrotis ~ perc_rocks + perc_2rocks + perc_3rocks + perc_4rocks + num_3rocks + num_4rocks ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(macrotis ~ perc_bareground + perc_vegetation + perc_herb_forb + perc_shrub + STDEV.NDVI_November_December,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
#No variables important

#Vegetation_3
#No variables important

#Geographic variables
full.model <- glm(macrotis ~ DEM.elevation + Slope , family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm (macrotis ~ perc_3rocks + perc_4rocks + perc_bareground + perc_vegetation + perc_herb_forb + DEM.elevation + Slope  ,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#### West Ladakh only 
lapply(c("perc_bareground","perc_vegetation","perc_rocks","perc_1rocks" ,"perc_2rocks","perc_3rocks","perc_4rocks","num_3rocks", "num_4rocks","num_shortgrass_sedge","num_tallgrass_reeds","num_herb_forb","num_shrub","num_cushionplant", "num_trees", "perc_shortgrass_sedge","perc_tallgrass_reeds", "perc_herb_forb", "perc_shrub", "perc_cushionplant", "perc_trees","height_shortgrass_sedge","height_tallgrass_reeds","height_herb_forb","height_shrub","height_cushionplant" ,"height_trees","DEM.elevation","Slope","Aspect", "Average.Delta.NDVI",  "STD.NDVI","Average.NDVI_Nov_Dec", "STDEV.NDVI_November_December", "Average.NDVI_July_August", "STDEV.NDVI_July_August"),
       function(var) {
         
         
         formula    <- as.formula(paste("macrotis ~", var))
         boxplotformula <- as.formula(paste(var,"~ macrotis"))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
         #plot_model(res.logist, type='pred', terms = var)
       })

#a)statistically relevant model
full.model <- glm(macrotis ~ num_4rocks + perc_4rocks + perc_rocks + perc_vegetation + Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


#b)Purposeful selection model
full.model <- glm(macrotis ~ num_4rocks + perc_4rocks + perc_rocks + perc_vegetation + DEM.elevation +height_shrub+height_herb_forb+height_tallgrass_reeds+perc_shrub + perc_herb_forb +perc_tallgrass_reeds + num_tallgrass_reeds+ num_shortgrass_sedge + num_3rocks + perc_bareground + Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August+ Average.Delta.NDVI ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)
variable_importance<-varImp(step.model, scale = FALSE)
write.csv(variable_importance,"OM_WestLadakh_purposefulmodel.csv")

#c)Sub-modelling approach
#rocks
full.model <- glm(macrotis ~  num_4rocks + perc_4rocks + perc_rocks + num_3rocks ,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_1
full.model <- glm(macrotis ~  perc_vegetation + perc_shrub + perc_herb_forb +perc_tallgrass_reeds + perc_bareground +  Average.NDVI_Nov_Dec + Average.NDVI_July_August + STDEV.NDVI_July_August + Average.Delta.NDVI,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_2
full.model <- glm(macrotis ~ num_tallgrass_reeds+ num_shortgrass_sedge,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Vegetation_3
full.model <- glm(macrotis ~ height_shrub+height_herb_forb+height_tallgrass_reeds,family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#Geographic variables
full.model <- glm(macrotis ~  DEM.elevation , family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)

#mixedmodel
full.model <- glm (macrotis ~ num_4rocks + perc_4rocks + perc_tallgrass_reeds + perc_bareground + Average.NDVI_July_August + Average.Delta.NDVI + num_shortgrass_sedge + height_tallgrass_reeds + DEM.elevation,family = binomial, data = d) 
step.model <- stepAIC(full.model, direction = "both", trace = TRUE)


####################################################checking for interactions
m001<- glm(macrotis ~Percentage_rocks * number_Herb._Forb_ * Percentage_Shrub, family = binomial, data = d)
summary(m001)
m002 <-glm(macrotis ~Percentage_rocks + number_Herb._Forb_ + Percentage_Shrub , family = binomial, data = d)
summary(m002)
lrtest(m002,m001)

#appears that interactions are not important. 

Predprob<-predict(m002,type="response")
plot(Predprob,jitter(as.numeric(m002$data$macrotis),0.5),cex=0.5,ylab="Jittered mortality outcome")

#doesn't exactly look like the best scenario out there. But will do for now I suppose.



## Refuge selection 

lapply(c("Ht.veg..Class.rock","Length","Width","Orientation","Endo.length"),
       function(var) {
         
         formula    <- as.formula(paste("Sign..1.H.S. ~", var))
         res.logist <- glm(formula, data = d, family = binomial)
         summary(res.logist)
       })

###stepwise selection_selectedvariables

full.model <- glm(Sign..1.H.S.~ Ht.veg..Class.rock + Length + Width + Orientation + Endo.length, family = binomial, data = d)
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)
summary(step.model)


##temperature data
d <- read.csv("~/Downloads/OM_temp data.csv")
full.model <- glm(Sign ~ Rock.class + Length + Width + Endo.length + mean.Tin...Tout. + stdev.Tin...Tout. + stdev.Tin., family=binomial, data=d )
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE)

lapply(c("Rock.class","Length","Width","Endo.length","mean.Tin...Tout.", "stdev.Tin...Tout.", "stdev.Tin."),
       function(var) {
         
         formula    <- as.formula(paste("Sign ~", var))
         res.logist <- glm(formula, data = d, family = binomial)
         plot_model(res.logist, type='pred', terms = var)
       })

full.model <- glm(Sign ~ Rock.class + Length + Endo.length + mean.Tin...Tout.,family=binomial, data=d)
step.model <- stepAIC(full.model, direction = "backward", trace = TRUE, maxit=1000)



